/* eslint-disable prettier/prettier */
export enum AddressTypes {
  DELIVERY = 'DELIVERY',
  BILLING = 'BILING',
}
