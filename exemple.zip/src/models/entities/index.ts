/* eslint-disable prettier/prettier */
import { Address } from './Address';
import { User } from './User';

export const Entities = [Address, User];
